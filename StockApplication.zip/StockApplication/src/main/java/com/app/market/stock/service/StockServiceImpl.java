package com.app.market.stock.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.market.stock.model.CompanyStock;
import com.app.market.stock.model.Stock;
import com.app.market.stock.repository.StockRepository;

@Service
public class StockServiceImpl implements StockService  {
	
	private StockRepository stockRepository;

	@Autowired
	public StockServiceImpl(StockRepository stockRepository) {
		this.stockRepository = stockRepository;
	}

	
	public CompanyStock addNewStock(CompanyStock companyStock) {
		
        return stockRepository.save(companyStock);
	}
	/*
	@Override
	public List<CompanyStock> getStock(String companyCode, Date startDate, Date endDate) {
		 
	        return stockRepository.findById(companyCode);
	}*/

}
