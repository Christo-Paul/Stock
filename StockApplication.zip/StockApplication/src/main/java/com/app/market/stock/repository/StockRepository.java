package com.app.market.stock.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.app.market.stock.model.CompanyStock;

public interface StockRepository extends MongoRepository<CompanyStock, String> {

}
