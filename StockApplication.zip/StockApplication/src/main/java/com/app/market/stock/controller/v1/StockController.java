package com.app.market.stock.controller.v1;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.market.stock.model.CompanyStock;
import com.app.market.stock.model.Stock;
import com.app.market.stock.service.StockService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {
	
	private StockService stockService;

    @Autowired
    public StockController(StockService stockService) {
        this.stockService = stockService;
    }
	
	@PostMapping("/add/{companyCode}")
	public ResponseEntity<?> addStock(@PathVariable String companyCode, @RequestBody CompanyStock companyStock) {
		companyStock.setCompanyCode(companyCode);
		return new ResponseEntity<>(stockService.addNewStock(companyStock), HttpStatus.CREATED);
	}
	
	@GetMapping("/get/{companyCode}/{startDate}/{endDate}")
	public ResponseEntity<?> getByCode(@PathVariable String companyCode, @PathVariable @DateTimeFormat (iso = DateTimeFormat.ISO.DATE) Date startDate, @PathVariable  @DateTimeFormat (iso = DateTimeFormat.ISO.DATE) Date endDate)  {
		return new ResponseEntity<>(stockService.getStock(companyCode, startDate,endDate), HttpStatus.OK);
	}

}
