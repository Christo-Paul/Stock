package com.app.market.stock.service;

import java.util.Date;
import java.util.List;

import com.app.market.stock.model.CompanyStock;

public interface StockService {

	CompanyStock addNewStock(CompanyStock companyStock);

	//List<CompanyStock> getStock(String companyCode, Date startDate, Date endDate);
}
