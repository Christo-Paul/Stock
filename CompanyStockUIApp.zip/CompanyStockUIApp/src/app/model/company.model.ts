export interface Company{

      companyCode ?: string;
      companyName ?: string;
      companyCEO ?: string;
      companyTurnover?:number;
      companyWebsite?: string;
      companyStockExchange?: string;
}