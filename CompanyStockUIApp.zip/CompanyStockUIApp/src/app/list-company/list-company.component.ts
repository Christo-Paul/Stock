import { Component, OnInit } from '@angular/core';
import { Company } from '../model/company.model';
import { CompanyService } from '../services/company.service';

@Component({
  selector: 'app-list-company',
  templateUrl: './list-company.component.html',
  styleUrls: ['./list-company.component.css']
})
export class ListCompanyComponent implements OnInit {
  content : Company[];
  response!: any;


  constructor(private companyService: CompanyService) { 
   this.content=[];
  }

  ngOnInit() {
    // fetch all the programs and assign to content
    this.companyService.getAll().subscribe(
      data => {
        this.content = data;
        // console.log("data" , data);
      },
      err => {
        this.content = JSON.parse(err.error).message;
      }
    );
  }

  onDelete(code: string){
    this.companyService.onDelete(code).subscribe(
      data => {
        this.response = data;
        // console.log("data" , data);
      },
      err => {
        this.response = JSON.parse(err.error).message;
      }
    );
  }
}
