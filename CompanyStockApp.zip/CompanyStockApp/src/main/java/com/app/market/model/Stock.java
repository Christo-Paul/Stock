package com.app.market.model;

import java.util.Date;

public abstract class Stock {
	
	private String name;
	private float price;
	private Date date;
	

}
