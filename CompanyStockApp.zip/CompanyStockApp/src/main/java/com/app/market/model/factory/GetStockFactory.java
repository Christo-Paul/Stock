package com.app.market.model.factory;

import com.app.market.model.CompanyStock;
import com.app.market.model.Stock;

public class GetStockFactory {

	public Stock getStock(String stockType) {
		if (stockType == null) {
			return null;
		}
		if (stockType.equalsIgnoreCase("COMPANYSTOCK")) {
			return new CompanyStock();
		}
		return null;
	}
}
