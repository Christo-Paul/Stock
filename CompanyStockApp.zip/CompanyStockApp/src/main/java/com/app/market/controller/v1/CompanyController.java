package com.app.market.controller.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.market.model.Company;
import com.app.market.service.CompanyService;

//@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1.0/market/company")
public class CompanyController {

	private CompanyService companyService;

    @Autowired
    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }
    
    @Autowired
    KafkaTemplate<String, String> template;
    

	@PostMapping("/register")
	public ResponseEntity<?> addCompany(@RequestBody Company company) {
		return new ResponseEntity<>(companyService.addCompanyDetails(company), HttpStatus.CREATED);
	}

	@GetMapping("getAll")
	public ResponseEntity<?> listAllCompanies() {
		template.send("devglan-test","Hello");
		return new ResponseEntity<>(companyService.listAllCompanies(), HttpStatus.OK);
	}

	@GetMapping("/info/{companyCode}")
	public ResponseEntity<?> getByCode(@PathVariable String companyCode)  {
		return new ResponseEntity<>(companyService.getCompanyByCode(companyCode), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{companyCode}")
	public ResponseEntity<?> deleteCompany(@PathVariable String companyCode) {
		companyService.deleteCompany(companyCode);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
