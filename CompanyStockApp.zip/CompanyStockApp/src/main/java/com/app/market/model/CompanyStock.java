package com.app.market.model;

public class CompanyStock extends Stock {

	private Company company; 
}
