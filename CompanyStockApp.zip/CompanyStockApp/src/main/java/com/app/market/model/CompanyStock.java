package com.app.market.model;

public class CompanyStocktu extends Stock {

	private String companyCode; 
}
