package com.app.market.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.app.market.model.Company;
import com.app.market.model.CompanyStock;
import com.app.market.model.Stock;
import com.app.market.repository.StockRepository;

public class StockServiceImpl implements StockService {
	
	private StockRepository stockRepository;

	@Autowired
	public StockServiceImpl(StockRepository stockRepository) {
		this.stockRepository = stockRepository;
	}

	@Override
	public CompanyStock addNewStock(CompanyStock companyStock) {
		
        return stockRepository.save(companyStock);
	}
	
	@Override
	public List<CompanyStock> getStock(String companyCode, Date startDate, Date endDate) {
		 
	        return stockRepository.findById(companyCode);
	}

}
