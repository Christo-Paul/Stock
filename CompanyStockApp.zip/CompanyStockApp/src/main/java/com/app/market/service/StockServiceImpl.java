package com.app.market.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.app.market.model.CompanyStock;
import com.app.market.model.Stock;
import com.app.market.repository.StockRepository;

public class StockServiceImpl implements StockService {
	
	private StockRepository StockRepository;

	@Autowired
	public StockServiceImpl(StockRepository StockRepository) {
		this.StockRepository = StockRepository;
	}

	@Override
	public CompanyStock addNewStock(CompanyStock companyStock) {
		if (StockRepository.findById(companyStock.getName()).isPresent()) {
            System.out.println("Stock already exists");
        }
        return StockRepository.save(companyStock);
	}

}
