package com.app.market.model;

import org.springframework.data.annotation.Id;

public class Company {
	
	@Id
    private String companyCode;
    private String companyName;
    private String companyCEO;
    private float companyTurnover;
    private String companyWebsite;
    private String companyStockExchange;
   
}
