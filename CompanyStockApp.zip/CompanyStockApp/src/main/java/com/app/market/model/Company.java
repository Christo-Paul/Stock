package com.app.market.model;

import org.springframework.data.annotation.Id;

public class Company {
	
	@Id
    private String companyCode;
    private String companyName;
    private String companyCEO;
    private float companyTurnover;
    private String companyWebsite;
    private String companyStockExchange;
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyCEO() {
		return companyCEO;
	}
	public void setCompanyCEO(String companyCEO) {
		this.companyCEO = companyCEO;
	}
	public float getCompanyTurnover() {
		return companyTurnover;
	}
	public void setCompanyTurnover(float companyTurnover) {
		this.companyTurnover = companyTurnover;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}
	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	public String getCompanyStockExchange() {
		return companyStockExchange;
	}
	public void setCompanyStockExchange(String companyStockExchange) {
		this.companyStockExchange = companyStockExchange;
	}
	@Override
	public String toString() {
		return "Company [companyCode=" + companyCode + ", companyName=" + companyName + ", companyCEO=" + companyCEO
				+ ", companyTurnover=" + companyTurnover + ", companyWebsite=" + companyWebsite
				+ ", companyStockExchange=" + companyStockExchange + "]";
	}
	public Company(String companyCode, String companyName, String companyCEO, float companyTurnover,
			String companyWebsite, String companyStockExchange) {
		super();
		this.companyCode = companyCode;
		this.companyName = companyName;
		this.companyCEO = companyCEO;
		this.companyTurnover = companyTurnover;
		this.companyWebsite = companyWebsite;
		this.companyStockExchange = companyStockExchange;
	}
	public Company() {
		super();
	}
   
    
}
