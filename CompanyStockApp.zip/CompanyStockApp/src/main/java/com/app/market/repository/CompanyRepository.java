package com.app.market.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.app.market.model.Company;

public interface CompanyRepository extends MongoRepository<Company, String> {

}
