package com.app.market.service;

import org.springframework.stereotype.Service;

import com.app.market.model.Company;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Override
	public Company addNewCompany(Company company) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Company listAllCompanies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Company getCompanyByCode(String companyCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCompany(String companyCode) {
		// TODO Auto-generated method stub
		
	}

}
