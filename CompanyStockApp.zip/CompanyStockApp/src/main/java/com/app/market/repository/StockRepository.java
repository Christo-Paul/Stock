package com.app.market.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.app.market.model.CompanyStock;

public interface StockRepository extends MongoRepository<CompanyStock, String> {

}
