package com.app.market.service;

import java.util.Date;
import java.util.List;

import com.app.market.model.CompanyStock;

public interface StockService {

	CompanyStock addNewStock(CompanyStock companyStock);

	List<CompanyStock> getStock(String companyCode, Date startDate, Date endDate);
}
