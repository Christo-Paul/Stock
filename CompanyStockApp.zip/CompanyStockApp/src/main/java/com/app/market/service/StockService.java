package com.app.market.service;

import com.app.market.model.CompanyStock;

public interface StockService {

	CompanyStock addNewStock(CompanyStock companyStock);
}
