package com.app.market.service;

public interface StockService {

}
