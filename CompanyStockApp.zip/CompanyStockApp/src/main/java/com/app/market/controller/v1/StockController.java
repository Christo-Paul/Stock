package com.app.market.controller.v1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.market.model.Company;
import com.app.market.model.Stock;
import com.app.market.service.CompanyService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {
	
	private CompanyService companyService;

    @Autowired
    public StockController(CompanyService companyService) {
        this.companyService = companyService;
    }
	
	@PostMapping("/add/{companycode}")
	public ResponseEntity<?> addStock(@PathVariable String companyCode, @RequestBody Stock stock) {
		Company company=companyService.getCompanyByCode(companyCode);
		return new ResponseEntity<>(companyService.addCompanyDetails(company), HttpStatus.CREATED);
	}
	
	@GetMapping("//get/{companycode}/{startdate}/{enddate}")
	public ResponseEntity<?> getByCode(@PathVariable String companyCode)  {
		return new ResponseEntity<>(companyService.getCompanyByCode(companyCode), HttpStatus.OK);
	}

}
