package com.app.market.service;

import java.util.List;

import com.app.market.model.Company;

public interface CompanyService {

	Company addNewCompany(Company company);

	List<Company> listAllCompanies();

	Company getCompanyByCode(String companyCode);

	void deleteCompany(String companyCode);

}
