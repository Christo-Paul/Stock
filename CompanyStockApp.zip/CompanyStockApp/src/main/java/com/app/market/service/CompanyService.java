package com.app.market.service;

import com.app.market.model.Company;

public interface CompanyService {

	Company addNewCompany(Company company);

	Company listAllCompanies();

	Company getCompanyByCode(String companyCode);

	void deleteCompany(String companyCode);

}
