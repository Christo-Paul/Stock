package com.app.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyStockAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
