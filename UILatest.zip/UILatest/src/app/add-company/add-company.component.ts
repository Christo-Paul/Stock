import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Company } from '../model/company.model';
import { CompanyService } from '../services/company.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {
  companyAdded= false;
  message='';

  constructor(private router: Router,private companyService: CompanyService) { 
   
   }
  ngOnInit(): void {
  }
  onSubmit(form: NgForm){
    let company: Company={

      companyCode : form.value.code,
      companyName: form.value.name,
      companyCEO : form.value.ceo,
      companyTurnover: form.value.turnover,
      companyWebsite: form.value.website,
      companyStockExchange: form.value.StockExchange

    }
    if(form.value.code.length>0 && form.value.turnover >20){

 this.companyService.onAdd(company).subscribe(
  data => {
    this.companyAdded =true;
    this.message = 'Company added';
    
    this.router.navigateByUrl('');
  },
  err=>{
    this.companyAdded =true;
     // this.message = err.error.message;    
     this.message = 'Exception Occurrred !! CompanyCode already exists'; 
      console.log(" exception in adding");        
  }
);
    console.log("value",form);
  }
  else{
    this.companyAdded =true;
    this.message = 'Enter Company Code !!';
  }


} 
  
}