import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CompanyStock } from '../model/companyStock.model';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json',
  'Access-Control-Allow-Origin':'*' },
  )
};
@Injectable({
  providedIn: 'root'
})
export class StockServiceService {
 
  

  constructor(private http: HttpClient) { }

  onFetchStocks(code: string) {
   
    return this.http.get('http://localhost:8091/api/v1.0/market/stock/get'+'/'+code+'/');
  }

  onFetchStocksByDate(code: string, start_date: string, end_date: string) {
    return this.http.get('http://localhost:8091/api/v1.0/market/stock/get'+'/'+code+'/'+start_date+'/'+end_date);
  }

  onFetchMinStockPrice(code: string, start_date: string, end_date: string) {
    return this.http.get('http://localhost:8091/api/v1.0/market/stock/get'+'/'+code+'/'+start_date+'/'+end_date+'/min');
  }
  onFetchMaxStockPrice(code: string, start_date: string, end_date: string) {
    return this.http.get('http://localhost:8091/api/v1.0/market/stock/get'+'/'+code+'/'+start_date+'/'+end_date+'/max');
  }
  onFetchAvgStockPrice(code: string, start_date: string, end_date: string) {
    return this.http.get('http://localhost:8091/api/v1.0/market/stock/get'+'/'+code+'/'+start_date+'/'+end_date+'/avg');
  }

  onAddStocks(stock:CompanyStock){
    return this.http.post('http://localhost:8091/api/v1.0/market/stock/add/'+'/'+stock.companyCode,stock);
  }

  onDeleteStocks(code: string) {
   
    return this.http.delete('http://localhost:8091/api/v1.0/market/stock/delete'+'/'+code+'/');
  }
}
