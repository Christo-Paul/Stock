import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from 'aws-amplify';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  email!:string;

  password!:string;


  constructor(private router:Router) { }


  ngOnInit(): void {

  }


  register(){

    try {

      const user = Auth.signUp({

        username: this.email,

        password: this.password,

      });

      console.log({ user });

      alert('User signup completed , please check verify your email.');

      this.router.navigate(['login']);

    } catch (error) {

      console.log('error signing up:', error);

    }

  }

}
