import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCompanyComponent } from './add-company/add-company.component';
import { ListCompanyComponent } from './list-company/list-company.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuardServiceService } from './services/auth-guard-service.service';
import { ViewStockComponent } from './view-stock/view-stock.component';

const routes: Routes = [
  { path: 'add', component: AddCompanyComponent , canActivate:[AuthGuardServiceService]},
  { path: '', component: ListCompanyComponent , canActivate:[AuthGuardServiceService]},
  { path: 'list', component: ListCompanyComponent , canActivate:[AuthGuardServiceService] },
  { path: 'stock', component: ViewStockComponent },
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
