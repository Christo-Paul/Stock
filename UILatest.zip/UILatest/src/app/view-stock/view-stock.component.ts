import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Company } from '../model/company.model';
import { CompanyStock } from '../model/companyStock.model';
import { CompanyService } from '../services/company.service';
import { StockServiceService } from '../services/stock-service.service';

@Component({
  selector: 'app-view-stock',
  templateUrl: './view-stock.component.html',
  styleUrls: ['./view-stock.component.css']
})
export class ViewStockComponent implements OnInit {
  companystocks : Company[];
  stocks: CompanyStock[];
  response!: any;
  chosenCompany: string = "";
  today: number = Date.now();
  statisticsDisplay= false;
  endDate :Date = new Date();  
  startDate: Date = new Date(); 
  maxStock: number | undefined;
  minStock : number | undefined;
  avgStock: number | undefined;
  fetchResponse!: CompanyStock;
  avgResponse: any;
  

  constructor(public datepipe: DatePipe,private companyService: CompanyService, private stockService: StockServiceService) { 
    this.companystocks=[];
  this.stocks=[]; }

  ngOnInit(): void {

    this.companyService.getAll().subscribe(
      data => {
        this.companystocks = data;
        // console.log("data" , data);
        
      },
      err => {
        this.companystocks = JSON.parse(err.error).message;
      }
    );
  }

  fetchStock(){
    console.log("data" , this.chosenCompany);
    this.stockService.onFetchStocks(this.chosenCompany).subscribe(
      data => {
        this.response = data;
         console.log("data" , data);
        
      },
      err => {
        this.response = JSON.parse(err.error).message;
      }
    );
   // window.location.reload();
  }

  fetchStockbyDates(){
   let start_date = this.datepipe.transform(this.startDate, 'yyyy-MM-dd');
    let end_date =this.datepipe.transform(this.endDate, 'yyyy-MM-dd');
    
    //console.log("comp" , this.chosenCompany);
    //console.log("st" , this.startDate);
    //console.log("ed" , this.endDate);
    //console.log("latestDate" , start_date);
    this.stockService.onFetchStocksByDate(this.chosenCompany,String(start_date),String(end_date))
    .subscribe(
      data => {
        this.response = data;
         console.log("data" , data);
         this.statisticsDisplay=true;
         this.fetchMinStock();
         this.fetchAvgStock();
         this.fetchMaxStock();
      },
      err => {
        this.response = JSON.parse(err.error).message;
      }
    );
  }
   // window.location.reload();
    
  

   fetchMinStock(){

    let start_date = this.datepipe.transform(this.startDate, 'yyyy-MM-dd');
    let end_date =this.datepipe.transform(this.endDate, 'yyyy-MM-dd');
    
    
    this.stockService.onFetchMinStockPrice(this.chosenCompany,String(start_date),String(end_date))
    .subscribe(
      data => {
        this.fetchResponse = data;
         console.log("min" , data);
         this.minStock=this.fetchResponse.price;
      },
      err => {
        this.fetchResponse = JSON.parse(err.error).message;
      }
    );
 

   }
   fetchMaxStock(){

   

    let start_date = this.datepipe.transform(this.startDate, 'yyyy-MM-dd');
    let end_date =this.datepipe.transform(this.endDate, 'yyyy-MM-dd');
    
    
    this.stockService.onFetchMaxStockPrice(this.chosenCompany,String(start_date),String(end_date))
    .subscribe(
      data => {
        this.fetchResponse = data;
         console.log("max" , data);
         this.maxStock=this.fetchResponse.price;
      },
      err => {
        this.fetchResponse = JSON.parse(err.error).message;
      }
    );
 

       }

       fetchAvgStock(){
        

    let start_date = this.datepipe.transform(this.startDate, 'yyyy-MM-dd');
    let end_date =this.datepipe.transform(this.endDate, 'yyyy-MM-dd');
    
    
    this.stockService.onFetchAvgStockPrice(this.chosenCompany,String(start_date),String(end_date))
    .subscribe(
      data => {
        this.avgResponse = data;
         console.log("avg" , data);
         this.avgStock=this.avgResponse;
      },
      err => {
        this.avgResponse = JSON.parse(err.error).message;
      }
    );
 

           }



}
